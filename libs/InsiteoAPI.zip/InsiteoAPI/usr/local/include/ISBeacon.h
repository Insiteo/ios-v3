//
//  ISBeacon.h
//  lbs
//
//  Created by dev_iphone on 02/12/2014.
//  Copyright (c) 2014 INSITEO. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ISTypes.h"

/*!
  Class used to represent a Beacon.
 */
@interface ISBeacon : NSObject

/*!
 Beacon UUID.
 */
@property (nonatomic, retain) NSString * uuid;

/*!
 Beacon Major.
 */
@property (nonatomic, readwrite) int major;

/*!
 Beacon Minor
 */
@property (nonatomic, readwrite) int minor;

/*!
 Beacon related site identifier.
 */
@property (nonatomic, readwrite) int siteId;

/*!
 Beacon related server type.
 */
@property (nonatomic, readwrite) ISEServerType serverType;

/*!
 Beacon external id (custom attribute).
 */
@property (nonatomic, retain) NSString * externalId;

/*!
 Beacon label.
 */
@property (nonatomic, retain) NSString * label;

/*!
 Beacon float extra 1.
 */
@property (nonatomic, readwrite) float fExtra1;

/*!
 Beacon String extra 1
 */
@property (nonatomic, retain) NSString * extra1;

/*!
 Beacon String extra 2
 */
@property (nonatomic, retain) NSString * extra2;

/*!
 Beacon String extra 3
 */
@property (nonatomic, retain) NSString * extra3;

@end
