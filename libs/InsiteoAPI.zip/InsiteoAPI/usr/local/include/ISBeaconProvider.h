//
//  BeaconProvider.h
//  LocationAPI
//
//  Created by dev_iphone on 10/12/13.
//  Copyright (c) 2013 INSITEO. All rights reserved.
//

/*!
 @header BeaconProvider.h
 BeaconProvider
 */

#import "ISLocationManager.h"

#import "ISBeaconRegion.h"
#import "ISPBeaconListener.h"
#import "ISCommonConstants.h"

/*!
 Class used to manage Insiteo Beacon and generic iBeacon.
 */
@interface ISBeaconProvider : ISLocationManager

#pragma mark - Singleton

/*!
 ISBeaconProvider singleton instance.
 */
+ (ISBeaconProvider *)sharedInstance;

#pragma mark - Properties

/*!
 Beacon Regions to monitor.
 */
@property (nonatomic, readonly) NSArray * beaconRegions;

/*!
 Beacon listener.
 */
@property (nonatomic, weak) id<ISPBeaconListener> listener;

#pragma mark - Load Beacon Regions

/*!
 Method used to load Beacon Regions from new configuration file.
 */
- (void)refreshBeacons;

#pragma mark - Add Monitoring Regions

/*!
 Method used to start monitoring Beacon Regions.
 @param listener Listener to notify of beacon events (mnonitoring and ranging).
 */
- (void)startWithListener:(id<ISPBeaconListener>)listener;

@end
