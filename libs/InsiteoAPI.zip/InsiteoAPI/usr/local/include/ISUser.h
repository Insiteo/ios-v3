//
//  ISUser.h
//  lbs
//
//  Created by dev_iphone on 08/12/2014.
//  Copyright (c) 2014 INSITEO. All rights reserved.
//

/*!
 @header ISUser.h
 ISUser
 */

#import <Foundation/Foundation.h>

#import "ISTypes.h"
#import "ISUserSite.h"

/*!
 Class used to represent an INSITEO user.
 */
@interface ISUser : NSObject

/*!
 User external unique identifier.
 */
@property (nonatomic, retain) NSString * guid;

/*!
 User related server type.
 */
@property (nonatomic, readwrite) ISEServerType serverType;

/*!
 User initialization language (language used during the SDK initialization process).
 */
@property (nonatomic, retain) NSString * initializationLanguage;

/*!
 Last API initialization date.
 */
@property (nonatomic, retain) NSDate * lastInitializationDate;

/*!
 User mail.
 */
@property (nonatomic, retain) NSString * mail;

/*!
 Application server URL.
 */
@property (nonatomic, retain) NSString * serverUrl;

/*!
 Current map render mode (2D or 3D).
 */
@property (nonatomic, readwrite) ISERenderMode renderMode;

/*!
 User float extra.
 */
@property (nonatomic, readwrite) float fExtra1;

/*!
 User NSString extra1.
 */
@property (nonatomic, retain) NSString * extra1;

/*!
 User NSString extra2.
 */
@property (nonatomic, retain) NSString * extra2;

/*!
 User NSString extra3.
 */
@property (nonatomic, retain) NSString * extra3;

/*!
 Method used to get a user site with its identifier.
 @param siteId Wanted site identifier.
 @return Return the wanted site (could be nil if not found).
 */
- (ISUserSite *)getSiteWithSiteId:(int)siteId;

/*!
 Method used to get all user sites.
 @return Return an NSDictionary (key = site identifier) of all user sites (could be nil).
 */
- (NSDictionary *)getSites;

@end
